@extends('layouts.admin')
@section('title')
Admin Dashboard | Know Your Inventory
@endsection
@section('admin_content')
<div class="container-fluid pt-2">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="">

                <div class="card-body">
                    @if (session('status'))
                    <div class="alert alert-success" role="alert">
                        {{ session('status') }}
                    </div>
                    @endif

                    <h1>Dashboard</h1>

                </div>
            </div>
        </div>
    </div>
</div>

@endsection
