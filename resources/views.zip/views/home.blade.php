@extends('layouts.avatar')
@section('title')
Templates | Know Your Inventory
@endsection
@section('avatar_content')

<style>
    .template-card{
        transition: all 1s;
        box-shadow: rgba(136, 165, 191, 0.48) 6px 2px 16px 0px, rgba(255, 255, 255, 0.8) -6px -2px 16px 0px; 
        text-align: center;
        border-radius: 12px;
        background-position: center;
        background-repeat: no-repeat;
        background-size: cover;
    }

    .template-card .card-inner{
        height: 100%;
        padding: 5rem 0px;
        background: #ffffffe8;
        border-radius: 12px;
    }

    .template-card h3 a{
        color: #000 !important;
    }
    
    .template-card:hover{
        transform: scale(1.1);
    }
</style>

<div class="row">
    <div class="col-12 text-center">
        <div class="py-5">
            <h1 class="" style="color: #E9C46A">Templates</h1>
            <br>
            <div class="hr-gradiant"></div>
        </div>
    </div>
    @if (session('status'))
    <div class="alert alert-success" role="alert">
        {{ session('status') }}
    </div>
    @endif
    @if (session('warning'))
    <div class="alert alert-danger" role="alert">
        {{ session('warning') }}
    </div>
    @endif

    @if($subscription != null )
    <div class="col-12 mb-5 text-center">
        <p>
            You are currently subscribed to - <span class="text-success">{{$subscription->plan_inf->name}} [${{ number_format($subscription->plan_inf->price * 0.01, 2) }} / {{$subscription->plan_inf->billing_period}}]</span> 
            <form action="{{route('subscription.cancel')}}" method="GET">
                @csrf
                <input type="hidden" name="subscriptionName" value="{{$subscription->name}}">
                &nbsp;<button type="submit" class="btn btn-secondary">Cancel</button>
            </form>
        </p>
    </div>
    @else
    <div class="col-12 mb-5 text-center">
        <p>
            <span class="text-danger">You are currently not subscribed. </span> 
            <a href="{{url('/plans')}}" class="btn custom-btn text-white me-3" type="button">See Plans</a>
           
        </p>
    </div>
    @endif

    <div class="col-lg-12 mb-5">
        <div class="row">
            @foreach($templates as $temp)
            <div class="col-lg-6 col-md-6 col-12 mx-auto my-2">
                <div class="template-card" style="background-image: url('{{asset('upload/template/'.$temp->image)}}')">
                    <div class="card-inner">
                        <h3><a href="{!!$temp->link!!}">{{$temp->name}}</a></h3>
                        <p>{!!$temp->description!!}</p>
                        @if($subscription != null )
                        <a href="{!!$temp->link!!}" class="btn custom-btn me-3">Use</a>
                        @else
                        <div class="col-12 mb-5 text-center">
                            <button type="button" class="btn btn-secondary" data-bs-toggle="modal" data-bs-target="#staticBackdrop">
                                See Demo
                            </button>
                        </div>
                        @endif
                    </div>
                    
                    <!-- Modal -->
                    <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                        <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                            <h5 class="modal-title" id="staticBackdropLabel">Demo Video</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                            ...
                            </div>
                            <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="button" class="btn btn-primary">Understood</button>
                            </div>
                        </div>
                        </div>
                    </div>
  
                </div>
            </div>
            @endforeach
        </div>
    </div>



    {{-- <div class="col-12 text-center">
        <div class="py-5">
            <h1 class="" style="color: #007565;">Recent Use</h1>
            <br>
            <div class="hr-gradiant"></div>
        </div>
    </div>

    <div class="col-12 ">
        <div class="table-responsive">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Title</th>
                        <th>Template</th>
                        <th>Date</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>1</td>
                        <td>Trial One</td>
                        <td>Open To Buy</td>
                        <td>30-01-2024</td>
                        <td><a href="#" class="btn custom-btn me-3">View</a></td>
                    </tr>
                    <tr>
                        <td>2</td>
                        <td>Trial Two</td>
                        <td>Cycle Count</td>
                        <td>02-02-2024</td>
                        <td><a href="#" class="btn custom-btn me-3">View</a></td>
                    </tr>
                    <tr>
                        <td>3</td>
                        <td>Trial Three</td>
                        <td>12 Month Forecast</td>
                        <td>04-02-2024</td>
                        <td><a href="#" class="btn custom-btn me-3">View</a></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div> --}}

</div>
@endsection
