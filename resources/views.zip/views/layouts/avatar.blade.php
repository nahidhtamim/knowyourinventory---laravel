<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <meta name="description" content="">
        <meta name="author" content="">

        <title>Know Your Inventory</title>

        <!-- CSS FILES -->        
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Unbounded:wght@300;400;600;700&display=swap" rel="stylesheet">
        <link href="{{ asset('frontend/css/bootstrap.min.css')}}" rel="stylesheet">
        <link href="{{ asset('frontend/css/bootstrap-icons.css')}}" rel="stylesheet">
        <link rel="stylesheet" href="https://unpkg.com/bootstrap-table@1.22.2/dist/bootstrap-table.min.css">
        <link rel="stylesheet" href="//cdn.datatables.net/1.13.7/css/jquery.dataTables.min.css">
        <link href="{{ asset('frontend/css/style.css')}}" rel="stylesheet">
        
        <!-- JAVASCRIPT FILES -->
        <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
        <script src="https://unpkg.com/bootstrap-table@1.22.2/dist/bootstrap-table.min.js"></script>
        <script src="//cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js"></script>
        <script src="{{ asset('frontend/js/jquery.sticky.js')}}"></script>
        <script src="{{ asset('frontend/js/click-scroll.js')}}"></script>
    </head>
    
    <body>

        <main>

            <nav class="navbar navbar-expand-lg bg-dark">
                <div class="container">
                    <a class="navbar-brand" href="{{ url('/') }}">
                        <img class="me-2" src="{{ asset('frontend/images/logo.png')}}" alt="" width="80px">
                        <span>Know Your Inventory</span>
                    </a>

                    {{-- <div class="d-lg-none ms-auto me-3">
                        @if (Route::has('register'))
                        <a href="{{ route('register') }}" class="btn custom-btn custom-border-btn btn-naira btn-inverted">
                            <i class="btn-icon bi-box-arrow-in-right"></i>
                            <span>Sign Up</span>
                        </a>
                        @endif
                        @if(Auth::user())
                            <a href="{{ route('logout') }}"  class="btn custom-btn custom-border-btn btn-naira btn-inverted" onclick="event.preventDefault();
                            document.getElementById('logout-form').submit();"><i class="btn-icon bi-box-arrow-in-left"></i><span>Log Out</span></a>
                            <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                                @csrf
                            </form>

                        @else
                            @if (Route::has('register'))
                            <a href="{{ route('register') }}" class="btn custom-btn custom-border-btn btn-naira btn-inverted">
                                <i class="btn-icon bi-box-arrow-in-right"></i>
                                <span>Sign Up</span>
                            </a>
                            @endif
                        @endif
                        
                    </div> --}}
    
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
    
                    <div class="collapse navbar-collapse" id="navbarNav">
                        <ul class="navbar-nav ms-lg-auto me-lg-4">
                            <li class="nav-item">
                                <a class="nav-link click-scroll" href="{{url('/')}}">Home</a>
                            </li>
                                
                            {{-- <li class="nav-item">
                                <a class="nav-link click-scroll" href="#section_2">About</a>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link click-scroll" href="#section_3">Templates</a>
                            </li> --}}

                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" id="navbarDarkDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                  More Links
                                </a>
                                <ul class="dropdown-menu dropdown-menu-dark" style="background: #000;" aria-labelledby="navbarDarkDropdownMenuLink">
                                    @foreach($pages as $page)
                                    <li><a class="dropdown-item" href="{{ route('page.details', ['slug' => $page->slug] )}}">{{$page->name}}</a></li>
                                    @endforeach
                                </ul>
                            </li>
                            @if(Auth::user())
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" data-bs-toggle="dropdown" href="#" role="button" aria-expanded="false">Hello, {{Auth::user()->name}}</a>
                                <ul class="dropdown-menu">
                                  <li><a class="dropdown-item" href="{{ route('home') }}">Dashboard</a></li>
                                  <li><a class="dropdown-item" href="{{ route('records') }}">Previous Records</a></li>
                                  {{-- <li><a class="dropdown-item" href="{{route('cycle.count')}}">Cycle Count</a></li>
                                  <li><a class="dropdown-item" href="{{route('tracking.twelve')}}">12 Month Forecast</a></li> --}}
                                  <li><hr class="dropdown-divider"></li>
                                  <li>
                                        {{-- <a class="dropdown-item" href="#">Separated link</a> --}}
                                        <a href="{{ route('logout') }}"  class="dropdown-item" onclick="event.preventDefault();
                                        document.getElementById('logout-form').submit();">Log Out</a>
                                        <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                                            @csrf
                                        </form>
                                    </li>
                                </ul>
                              </li>
                            @endif
                        </ul>

                        {{-- <div class="d-none d-lg-block">
                            @if(Auth::user())
                                <a href="{{ route('logout') }}"  class="btn custom-btn custom-border-btn btn-naira btn-inverted" onclick="event.preventDefault();
                                document.getElementById('logout-form').submit();"><i class="btn-icon bi-box-arrow-in-left"></i><span>Log Out</span></a>
                                <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                                    @csrf
                                </form>
                            @else
                                @if (Route::has('register'))
                                <a href="{{ route('register') }}" class="btn custom-btn custom-border-btn btn-naira btn-inverted">
                                    <i class="btn-icon bi-box-arrow-in-right"></i>
                                    <span>Sign Up</span>
                                </a>
                                @endif
                            @endif
                        </div> --}}

                    </div>
                </div>
            </nav>
            <section class=" section-padding" style="padding-top: 120px">
                <div class="container">
                    @yield('avatar_content')
                </div>
            </section>
           

            <section class="contact-section section-padding" id="section_5">
                <div class="container">
                    <div class="row">

                        <div class="col-lg-5 col-12 mx-auto">
                            <form class="custom-form ebook-download-form bg-white shadow" action="#" method="post" role="form">
                                <div class="text-center mb-5">
                                    <h2 class="mb-1">Contact Us</h2>
                                </div>

                                <div class="ebook-download-form-body">
                                    <div class="input-group mb-4">
                                        <input type="text" name="ebook-form-name" id="ebook-form-name" class="form-control" aria-label="ebook-form-name" aria-describedby="basic-addon1" placeholder="Your Name" required>

                                        <span class="input-group-text" id="basic-addon1">
                                            <i class="custom-form-icon bi-person"></i>
                                        </span>
                                    </div>

                                    <div class="input-group mb-4">
                                        <input type="email" name="ebook-email" id="ebook-email" pattern="[^ @]*@[^ @]*" class="form-control" placeholder="your@company.com" aria-label="ebook-form-email" aria-describedby="basic-addon2" required="">

                                        <span class="input-group-text" id="basic-addon2">
                                            <i class="custom-form-icon bi-envelope"></i>
                                        </span>
                                    </div>

                                    <div class="col-lg-8 col-md-10 col-8 mx-auto">
                                        <button type="submit" class="form-control">Send</button>
                                    </div>
                                </div>
                            </form>
                        </div>

                        <div class="col-lg-6 col-12">
                            <h6 class="mt-5">Say hi and talk to us</h6>

                            <h2 class="mb-4">Contact</h2>

                            <!-- <p class="mb-3">
                                <i class="bi-geo-alt me-2"></i>
                                London, United Kingdom
                            </p>

                            <p class="mb-2">
                                <a href="tel: 010-020-0340" class="contact-link">
                                    010-020-0340
                                </a>
                            </p> -->

                            <p>
                                <a href="mailto:info@company.com" class="contact-link">
                                    info@company.com
                                </a>
                            </p>

                            <h6 class="site-footer-title mt-5 mb-3">Social</h6>

                            <ul class="social-icon mb-4">
                                <li class="social-icon-item">
                                    <a href="#" class="social-icon-link bi-instagram"></a>
                                </li>

                                <li class="social-icon-item">
                                    <a href="#" class="social-icon-link bi-twitter"></a>
                                </li>
                                
                                <li class="social-icon-item">
                                    <a href="#" class="social-icon-link bi-facebook"></a>
                                </li>

                                <li class="social-icon-item">
                                    <a href="#" class="social-icon-link bi-whatsapp"></a>
                                </li>
                            </ul>

                            <p class="copyright-text">Copyright © Agency-Consulting Co. 2023
                            <br><br><a rel="nofollow" href="" target="_blank">developed by NHT</a></p>
                        </div>

                    </div>
                </div>
            </section>
        </main>

    <!-- JAVASCRIPT FILES -->
    {{-- <script src="{{ asset('frontend/js/jquery.min.js')}}"></script>
    <script src="{{ asset('frontend/js/bootstrap.bundle.min.js')}}"></script> --}}
    
    <script src="{{ asset('frontend/js/custom.js')}}"></script>
    <script>let table = new DataTable('.dataTable');</script>

    <!-- Include dom-to-image library -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/dom-to-image/2.6.0/dom-to-image.min.js"></script>

    <!-- Add this script section at the end of your Blade file -->
    <script>
        function printCard() {
            // Use dom-to-image to convert the card to an image
            domtoimage.toPng(document.querySelector('.print-card'))
                .then(function (dataUrl) {
                    // Create a new window to display the image
                    var printWindow = window.open('', '_blank');
                    printWindow.document.open();
                    printWindow.document.write('<html><head><title>Print</title></head><body>');
                    printWindow.document.write('<img src="' + dataUrl + '">');
                    printWindow.document.write('</body></html>');
                    printWindow.document.close();

                    // Wait for the image to load before triggering print
                    printWindow.onload = function () {
                        printWindow.print();
                        printWindow.onafterprint = function () {
                            printWindow.close();
                        };
                    };
                })
                .catch(function (error) {
                    console.error('Error generating image:', error);
                });
        }
    </script>

</body>
</html>