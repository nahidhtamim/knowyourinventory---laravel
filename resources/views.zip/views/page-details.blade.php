@extends('layouts.avatar')
@section('title')
{{$page->name}} | Know Your Inventory
@endsection
@section('avatar_content')

    

    <div class="row">
        <div class="col-12 text-center">
            <div class="py-5">
                <h1 class="" style="color: var(--secondary-color);">{{$page->name}}</h1>
                <br>
                <div class="hr-gradiant"></div>
            </div>
        </div>
        @if (session('status'))
        <div class="alert alert-success" role="alert">
            {{ session('status') }}
        </div>
        @endif
        <div class="col-lg-8 mx-auto pt-5">
            {!! $page->description !!}

            <img class="img-fluid" src="{{asset('upload/page/'.$page->image)}}"  alt="" style="width: 80%; border-radius: 12px; box-shadow: rgba(136, 165, 191, 0.48) 6px 2px 16px 0px, rgba(255, 255, 255, 0.8) -6px -2px 16px 0px;">
        </div>
    </div>
@endsection
