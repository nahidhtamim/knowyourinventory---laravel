@extends('layouts.avatar')
@section('title')
Subscription Plans | Know Your Inventory
@endsection
@section('avatar_content')
<div class="container">
	<div class="row justify-content-center">
		<div class="col-12 text-center">
            <div class="py-5">
                <h1 class="" style="color: #E9C46A;">Subsciption Plans</h1>
                <br>
                <div class="hr-gradiant"></div>
            </div>
        </div>
        @if (session('status'))
        <div class="alert alert-success" role="alert">
            {{ session('status') }}
        </div>
        @endif
        <div class="col-12 ">

			<div class="row">
				@foreach($plans as $plan)
				<div class="col-md-6 mx-auto">
					<div class="card mb-3 text-center">
						<div class="card-header"> 
							${{$plan->price * 0.01}} / {{$plan->billing_period}}
						</div>
						<div class="card-body">
							<h5 class="card-title">{{ $plan->name }}</h5>
							<p>{{ $plan->description }}</p>
							{{-- <p class="card-text">Please Select Plan</p> --}}
							<a href="{{ route('plans.show', $plan->slug) }}" class="btn btn-primary pull-right">Purchase</a>
						</div>
					</div>
				</div>
				@endforeach
			</div>

		</div>
	</div>
</div>
@endsection