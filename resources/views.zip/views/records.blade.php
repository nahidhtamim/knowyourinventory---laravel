@extends('layouts.avatar')
@section('title')
Records | Know Your Inventory
@endsection
@section('avatar_content')

<div class="row">

    <div class="col-12 text-center">
        <div class="py-5">
            <h1 class="" style="color: #007565;">Previous Records</h1>
            <br>
            <div class="hr-gradiant"></div>
        </div>
    </div>
    @if (session('status'))
    <div class="alert alert-success" role="alert">
        {{ session('status') }}
    </div>
    @endif
    <div class="col-lg-6 mx-auto text-center my-3">
        
        <div class="table-responsive card p-2 shadow">
            <h4>12 Monthly Forecast</h4>
            <hr>
            <table class="table table-bordered dataTable" id="dataTable">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Title</th>
                        <th>Date</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($monthly_forecasts as $forecast)
                    <tr>
                        <td>{{$loop->iteration}}</td>
                        <td>{{$forecast->title}}</td>
                        <td>{{$forecast->created_at->format('Y-m-d');}}</td>
                        <td><a href="{{ route('tracking.twelve.details', ['id' => $forecast->id] )}}" class="btn custom-btn me-3">View</a></td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
    <div class="col-lg-6 mx-auto text-center my-3">
        
        <div class="table-responsive card p-2 shadow">
            <h4>Cycle Count</h4>
            <hr>
            <table class="table table-bordered dataTable" id="dataTable">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Title</th>
                        <th>Inventory Adjustment</th>
                        <th>SKU Count</th>
                        <th>Date</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($cycle_counts as $cycle)
                    <tr>
                        <td>{{$loop->iteration}}</td>
                        <td>{{$cycle->title}}</td>
                        <td>{{$cycle->inv_adjustment}}</td>
                        <td>{{$cycle->sku_count}}</td>
                        <td>{{$cycle->created_at->format('Y-m-d');}}</td>
                        <td><a href="{{ route('cycle.count.details', ['id' => $cycle->id] )}}" class="btn custom-btn me-3">View</a></td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>

    <div class="col-lg-6 mx-auto text-center my-3">
        
        <div class="table-responsive card p-2 shadow">
            <h4>Open To Buy</h4>
            <hr>
            <table class="table table-bordered dataTable" id="dataTable">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Title</th>
                        <th>Date</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($open_buys as $open)
                    <tr>
                        <td>{{$loop->iteration}}</td>
                        <td>{{$open->title}}</td>
                        <td>{{$open->created_at->format('Y-m-d');}}</td>
                        <td><a href="{{ route('open.buy.details', ['id' => $open->id] )}}" class="btn custom-btn me-3">View</a></td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection
