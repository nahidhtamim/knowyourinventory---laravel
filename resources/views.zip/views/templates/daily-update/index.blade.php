@extends('layouts.avatar')
@section('title')
Daily Update | Know Your Inventory
@endsection
@section('avatar_content')

@if (session('status'))
<div class="alert alert-success" role="alert">
    {{ session('status') }}
</div>
@endif

<div class="row">
    <form action="{{route('save.daily.update')}}" method="POST">
        @csrf
        <div class="col-12 text-center">
            <div class="py-5">
                <h1>Daily Update</h1>
            </div>
        </div>
        <div class="col-12 text-center">
            <div class="py-5">
                <label for="title">Project Title</label>
                <input type="text" class="form-control" name="title" placeholder="Project Title">
            </div>
        </div>
        <div class="col-lg-12">
            <div class="accordion" id="accordionExample">
                <div class="accordion-item">
                  <h2 class="accordion-header" id="headingOne">
                    <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                      HQ Monthly Goal
                    </button>
                  </h2>
                  <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne">
                    <div class="accordion-body">
                        <div class="table-responsive">
                            <div class="form-group mb-3">
                                <div class="input-group">
                                    <input type="text" class="form-control name_one" name="name_one" placeholder="Enter Name">
                                    <input type="number" step="0.01" class="form-control amount_one" name="amount_one" placeholder="$0.00">
                                </div>
                            </div>
                            <div class="form-group mb-3">
                                <div class="input-group">
                                    <input type="text" class="form-control name_two" name="name_two" placeholder="Enter Name">
                                    <input type="number" step="0.01" class="form-control amount_two" name="amount_two" placeholder="$0.00">
                                </div>
                            </div>
                            <div class="form-group mb-3">
                                <div class="input-group">
                                    <input type="text" class="form-control name_three" name="name_three" placeholder="Enter Name">
                                    <input type="number" step="0.01" class="form-control amount_three" name="amount_three" placeholder="$0.00">
                                </div>
                            </div>
                            <div class="form-group mb-3">
                                <div class="input-group">
                                    <input type="text" class="form-control name_four" name="name_four" placeholder="Enter Name">
                                    <input type="number" step="0.01" class="form-control amount_four" name="amount_four" placeholder="$0.00">
                                </div>
                            </div>
                        </div>
                    </div>
                  </div>
                </div>
                <div class="accordion-item">
                  <h2 class="accordion-header" id="headingTwo">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                      Input
                    </button>
                  </h2>
                  <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo">
                    <div class="accordion-body">
                      <div class="table-responsive">
                        <table class="table table-bordered table-condensed table-striped">
                            <thead class="text-center">
                              <tr>
                                <th rowspan="2">Goals</th>
                                <th rowspan="2">Day</th>
                                <th rowspan="2">Date</th>
                                <th colspan="3"><input type="text" name="name_one_output" id="" class="form-control" placeholder="Name" readonly></th>
                                <th colspan="3"><input type="text" name="name_two_output" id="" class="form-control" placeholder="Name" readonly></th>
                                <th colspan="3"><input type="text" name="name_three_output" id="" class="form-control" placeholder="Name" readonly></th>
                                <th colspan="3"><input type="text" name="name_four_output" id="" class="form-control" placeholder="Name" readonly></th>
                              </tr>
                              <tr>
                                <th>Sales</th>
                                <th>INV</th>
                                <th>Lines</th>
                                <th>Sales</th>
                                <th>INV</th>
                                <th>Lines</th>
                                <th>Sales</th>
                                <th>INV</th>
                                <th>Lines</th>
                                <th>Sales</th>
                                <th>INV</th>
                                <th>Lines</th>
                              </tr>
                            </thead>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="accordion-item">
                  <h2 class="accordion-header" id="headingThree">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                      MO. Overview
                    </button>
                  </h2>
                  <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree">
                    <div class="accordion-body">
                      <strong>This is the third item's accordion body.</strong> It is hidden by default, until the collapse plugin adds the appropriate classes that we use to style each element. These classes control the overall appearance, as well as the showing and hiding via CSS transitions. You can modify any of this with custom CSS or overriding our default variables. It's also worth noting that just about any HTML can go within the <code>.accordion-body</code>, though the transition does limit overflow.
                    </div>
                  </div>
                </div>
            </div>
            
            <div class="text-center my-5">
                <button class="btn px-5" type="submit" style="background: #E9C46A;">Save</button>
            </div>
        </div>
    </form>
</div>


@endsection
