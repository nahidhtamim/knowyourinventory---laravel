@extends('layouts.avatar')
@section('title')
12 Month Forecast | Know Your Inventory
@endsection
@section('avatar_content')

@if (session('status'))
<div class="alert alert-success" role="alert">
    {{ session('status') }}
</div>
@endif

@php

    $months = ['jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec'];

    $walkInData = json_decode($forecastData->walk_in, true);
    $webPurchaseData = json_decode($forecastData->web_purchase, true);
    $totalOneData = json_decode($forecastData->total_one, true);
    $estimatedPurchaseData = json_decode($forecastData->estimated_purchase, true);
    $totalTwoData = json_decode($forecastData->total_two, true);
    $perInvoiceData = json_decode($forecastData->per_invoice, true);
    $monthlyTotalData = json_decode($forecastData->monthly_total, true);
    $businessDaysData = json_decode($forecastData->business_days, true);
    $perDayData = json_decode($forecastData->per_day, true);
    $walkInPerDayData = json_decode($forecastData->walk_in_per_day, true);
@endphp

<div class="row print-card my-5">
        <div class="col-12 text-center">
            <div class="py-5">
                <img class="me-2" src="{{ asset('frontend/images/logo.png')}}" alt="" width="80px">
                <h3> KYI - 12 Month Forecast</h3>
                <hr>
            </div>
        </div>
        <div class="col-lg-12">
            <h4 class="py-3">Project Title: {{$forecastData->title}}</h4>
            <div class="table-responsive">
                <table class="table table-bordered table-condensed table-striped dataTable monthly-forcast">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Jan</th>
                            <th>Feb</th>
                            <th>Mar</th>
                            <th>Apr</th>
                            <th>May</th>
                            <th>Jun</th>
                            <th>Jul</th>
                            <th>Aug</th>
                            <th>Sep</th>
                            <th>Oct</th>
                            <th>Nov</th>
                            <th>Dec</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>Customer Traffic</td>
                            <td class="bg-dark" colspan="12"></td>
                        </tr>
                        <tr>
                            <td>Walk-In</td>
                            
                            @foreach($months as $month)
                                <td>{{ $walkInData[$month] ?? '' }}</td>
                            @endforeach
                        </tr>
                        
                        <tr>
                            <td>Web Purchase</td>
                            
                            @foreach($months as $month)
                                <td>{{ $webPurchaseData[$month] ?? '' }}</td>
                            @endforeach
                        </tr>
                        <tr>
                            <td>Total</td>
                            
                            @foreach($months as $month)
                                <td>{{ $totalOneData[$month] ?? '' }}</td>
                            @endforeach
                        </tr>
                        <tr>
                            <td>Total</td>
                            
                            @foreach($months as $month)
                                <td>{{ $estimatedPurchaseData[$month] ?? '' }}</td>
                            @endforeach
                        </tr>
                        <tr>
                            <td>Total</td>
                            
                            @foreach($months as $month)
                                <td>{{ $totalTwoData[$month] ?? '' }}</td>
                            @endforeach
                        </tr>
                        <tr>
                            <td>$ Per Invoice</td>
                            
                            @foreach($months as $month)
                                <td>{{ $perInvoiceData[$month] ?? '' }}</td>
                            @endforeach
                        </tr>
                        <tr>
                            <td>Monthly Total Sales</td>
                            
                            @foreach($months as $month)
                                <td>{{ $monthlyTotalData[$month] ?? '' }}</td>
                            @endforeach
                        </tr>
                        <tr>
                            <td># Business Days</td>
                            
                            @foreach($months as $month)
                                <td>{{ $businessDaysData[$month] ?? '' }}</td>
                            @endforeach
                        </tr>
                        <tr>
                            <td># Per Days</td>
                            
                            @foreach($months as $month)
                                <td>{{ $perDaysData[$month] ?? '' }}</td>
                            @endforeach
                        </tr>

                        <tr>
                            <td class="bg-dark" colspan="13"></td>
                        </tr>
                        <tr>
                            <td>Walk-In Per Day Estimator</td>
                            
                            @foreach($months as $month)
                                <td>{{ $walkInPerDayData[$month] ?? '' }}</td>
                            @endforeach
                        </tr>
                    </tbody>
                </table>
            </div>
            
        </div>
</div>
<div class="text-center my-5">
    <button class="btn px-5" type="button" style="background: #E9C46A;" onclick="printCard()">Print</button>
</div>
@endsection
