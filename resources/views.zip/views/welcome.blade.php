<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <meta name="description" content="">
        <meta name="author" content="">

        <title>Know Your Inventory</title>

        <!-- CSS FILES -->        
        <link rel="preconnect" href="https://fonts.googleapis.com">
        
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

        <link href="https://fonts.googleapis.com/css2?family=Unbounded:wght@300;400;600;700&display=swap" rel="stylesheet">

        <link href="{{ asset('frontend/css/bootstrap.min.css')}}" rel="stylesheet">

        <link href="{{ asset('frontend/css/bootstrap-icons.css')}}" rel="stylesheet">

        <link href="{{ asset('frontend/css/style.css')}}" rel="stylesheet">

    </head>
    
    <body>

        <main>

            <nav class="navbar navbar-expand-lg">
                <div class="container">
                    <a class="navbar-brand d-none d-lg-block" href="{{ url('/') }}">
                        <img class="me-2" src="{{ asset('frontend/images/logo.png')}}" alt="" width="80px">
                        <span class="">Know Your Inventory</span>
                    </a>
                    <a class="navbar-brand d-lg-none" href="{{ url('/') }}">
                        <img class="me-2" src="{{ asset('frontend/images/logo.png')}}" alt="" width="80px">
                        
                    </a>

                    <div class="d-lg-none ms-auto me-3">
                        {{-- @if (Route::has('register'))
                        <a href="{{ route('register') }}" class="btn custom-btn custom-border-btn btn-naira btn-inverted">
                            <i class="btn-icon bi-box-arrow-in-right"></i>
                            <span>Sign Up</span>
                        </a>
                        @endif --}}
                        @if(Auth::user())
                            <a href="{{ route('logout') }}"  class="btn custom-btn custom-border-btn btn-naira btn-inverted" onclick="event.preventDefault();
                            document.getElementById('logout-form').submit();"><i class="btn-icon bi-box-arrow-in-left"></i><span>Log Out</span><!-- duplicated above one for mobile --></a>
                            <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                                @csrf
                            </form>

                        @else
                            @if (Route::has('login'))
                            <a href="{{ route('login') }}" class="btn custom-btn custom-border-btn btn-naira btn-inverted">
                                <i class="btn-icon bi-box-arrow-in-right"></i>
                                <span>Sign In</span><!-- duplicated above one for mobile -->
                            </a>
                            @endif
                        @endif
                        
                    </div>
    
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
    
                    <div class="collapse navbar-collapse" id="navbarNav">
                        <ul class="navbar-nav ms-lg-auto me-lg-4">
                            <li class="nav-item">
                                <a class="nav-link click-scroll" href="{{url('/')}}">Home</a>
                            </li>
    
                            {{-- <li class="nav-item">
                                <a class="nav-link click-scroll" href="#section_2">About</a>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link click-scroll" href="#section_3">Templates</a>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link click-scroll" href="#section_4">Reviews</a>
                            </li> --}}

                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" id="navbarDarkDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                  More Links
                                </a>
                                <ul class="dropdown-menu dropdown-menu-dark" style="background: #000;" aria-labelledby="navbarDarkDropdownMenuLink">
                                    @foreach($pages as $page)
                                    <li><a class="dropdown-item" href="{{ route('page.details', ['slug' => $page->slug] )}}">{{$page->name}}</a></li>
                                    @endforeach
                                </ul>
                            </li>
                            @if(Auth::user())
                            <li class="nav-item">
                                <a class="nav-link" href="{{ route('home') }}">Dashboard</a>
                            </li>
                            @endif
                        </ul>

                        <div class="d-none d-lg-block">
                            @if(Auth::user())
                                <a href="{{ route('logout') }}"  class="btn custom-btn custom-border-btn btn-naira btn-inverted" onclick="event.preventDefault();
                                document.getElementById('logout-form').submit();"><i class="btn-icon bi-box-arrow-in-left"></i><span>Log Out</span><!-- duplicated above one for mobile --></a>
                                <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                                    @csrf
                                </form>

                            @else
                                @if (Route::has('login'))
                                <a href="{{ route('login') }}" class="btn custom-btn custom-border-btn btn-naira btn-inverted">
                                    <i class="btn-icon bi-box-arrow-in-right"></i>
                                    <span>Sign In</span><!-- duplicated above one for mobile -->
                                </a>
                                @endif
                            @endif
                            
                        </div>
                    </div>
                </div>
            </nav>
            

            <section class="hero-section d-flex justify-content-center align-items-center" id="section_1">
                <div class="container">
                    <div class="row">

                        <div class="col-lg-6 col-12 mb-5 pb-5 pb-lg-0 mb-lg-0">

                            <h6>{{$hero_text->title}}</h6>

                            <h1 class="text-white mb-4">{!!$hero_text->description!!}</h1>
                            <!-- <h1 class="text-white mb-4">Do you have the right inventory management for a Healthy Inventory?</h1> -->

                            <a href="#section_3" class="btn custom-btn smoothscroll me-3">Templates</a>

                        </div>

                        <div class="hero-image-wrap col-lg-6 col-12 mt-3 mt-lg-0">
                            <img src="{{asset('upload/web_content/'.$hero_text->media)}}" class="hero-image img-fluid" alt="{{$hero_text->title}}">
                        </div>

                    </div>
                </div>
            </section>


            <section class="featured-section">
                <div class="container">
                    <div class="row">

                        <div class="col-lg-8 col-12">
                            <div class="avatar-group d-flex flex-wrap align-items-center">
                                <img src="{{ asset('frontend/images/avatar/portrait-beautiful-young-woman-standing-grey-wall.jpg')}}" class="img-fluid avatar-image" alt="">

                                <img src="{{ asset('frontend/images/avatar/portrait-young-redhead-bearded-male.jpg')}}" class="img-fluid avatar-image avatar-image-left" alt="">

                                <img src="{{ asset('frontend/images/avatar/pretty-blonde-woman.jpg')}}" class="img-fluid avatar-image avatar-image-left" alt="">

                                <img src="{{ asset('frontend/images/avatar/studio-portrait-emotional-happy-funny-smiling-boyfriend.jpg')}}" class="img-fluid avatar-image avatar-image-left" alt="">

                                <div class="reviews-group mt-3 mt-lg-0" style="color: var(--secondary-color);">
                                    <strong>5</strong>

                                    <i class="bi-star-fill"></i>
                                    <i class="bi-star-fill"></i>
                                    <i class="bi-star-fill"></i>
                                    <i class="bi-star-fill"></i>
                                    <i class="bi-star-fill"></i>

                                    <small class="ms-3">100% Satisfied Clients</small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>


            <section class="py-lg-5"></section>


            <section class="book-section section-padding" id="section_2">
                <div class="container">
                    <div class="row">

                        <div class="col-lg-6 col-12">
                            <img src="{{asset('upload/web_content/'.$about_text->media)}}" class="img-fluid" alt="">
                        </div>

                        <div class="col-lg-6 col-12">
                            <div class="book-section-info">
                                <h6>{{$about_text->title}}</h6>


                                <h2 class="mb-4">About Us</h2>

                                <p>{!!$about_text->description!!}</p>
                            </div>
                        </div>

                    </div>
                </div>
            </section>


            <section id="section_3">
                <div class="container">
                    <div class="row">

                        <div class="col-lg-12 col-12 text-center">
                            <h6>KPI Templates</h6>
                            <h2 class="mb-2">{{$kpi_first_text->description}}</h2>
                            <p>{{$kpi_sec_text->description}}</p>
                        </div>

                        <div class="col-lg-4 col-12">
                            <nav id="navbar-example3" class="h-100 flex-column align-items-stretch">
                                <nav class="nav nav-pills flex-column">
                                    <a class="nav-link smoothscroll" href="#item-{{$open_text->id}}">{{$open_text->title}}</a>

                                    <a class="nav-link smoothscroll" href="#item-{{$forecast_text->id}}">{{$forecast_text->title}}</a>

                                    <a class="nav-link smoothscroll" href="#item-{{$cycle_count_text->id}}">{{$cycle_count_text->title}}</a>

                                    <a class="nav-link smoothscroll" href="#item-{{$track_daily_text->id}}">{{$track_daily_text->title}}</a>

                                </nav>
                            </nav>
                        </div>

                        <div class="col-lg-8 col-12">
                            <div data-bs-spy="scroll" data-bs-target="#navbar-example3" data-bs-smooth-scroll="true" class="scrollspy-example-2" tabindex="0">
                                <div class="scrollspy-example-item" id="item-{{$open_text->id}}">
                                    <h5>{{$open_text->title}}</h5>

                                    <p>{!!$open_text->description!!}</p> 

                                    <img src="{{asset('upload/web_content/'.$open_text->media)}}" alt="" width="100%">
                                </div>

                                <div class="scrollspy-example-item" id="item-{{$forecast_text->id}}">
                                    <h5>{{$forecast_text->title}}</h5>

                                    <p>{!!$forecast_text->description!!}</p>

                                    <img src="{{asset('upload/web_content/'.$forecast_text->media)}}" alt="" width="100%">
                                </div>

                                <div class="scrollspy-example-item" id="item-{{$cycle_count_text->id}}">

                                    <h5>{{$cycle_count_text->title}}</h5>

                                    <p>{!!$cycle_count_text->description!!}</p>

                                    <img src="{{asset('upload/web_content/'.$cycle_count_text->media)}}" alt="" width="100%">
                                </div>

                                <div class="scrollspy-example-item" id="item-{{$track_daily_text->id}}">
                                    <h5>{{$track_daily_text->title}}</h5>

                                    <p>{!!$track_daily_text->description!!}</p>

                                    <img src="{{asset('upload/web_content/'.$track_daily_text->media)}}" alt="" width="100%">
                                </div>

                            </div>
                        </div>

                    </div>
                </div>
            </section>


            <!-- <section class="author-section section-padding">
                <div class="container">
                    <div class="row">

                        <div class="col-lg-6 col-12">
                            <img src="{{ asset('frontend/images/portrait-mature-smiling-authoress-sitting-desk.jpg')}}" class="author-image img-fluid" alt="">
                        </div>

                        <div class="col-lg-6 col-12 mt-5 mt-lg-0">
                            <h6>Meet Author</h6>

                            <h2 class="mb-4">Prof. Sophia</h2>

                            <p>This is an ebook landing page template with Bootstrap 5 CSS framework. It is easy to customize with the use of Bootstrap CSS classes.</p>

                            <p>Lorem ipsum dolor sit amet, consive adipisicing elit, sed do eiusmod. tempor incididunt ut labore.</p>
                        </div>

                    </div>
                </div>
            </section> -->


            <section class="reviews-section section-padding" id="section_4">
                <div class="container">
                    <div class="row">

                        <div class="col-lg-12 col-12 text-center mb-5">
                            <h6>Reviews</h6>

                            <h2>What people saying...</h2>
                        </div>

                        <div class="col-lg-4 col-12">
                            <div class="custom-block d-flex flex-wrap">
                                <div class="custom-block-image-wrap d-flex flex-column">
                                    <img src="{{ asset('frontend/images/avatar/portrait-beautiful-young-woman-standing-grey-wall.jpg')}}" class="img-fluid avatar-image" alt="">

                                    <div class="text-center mt-3">
                                        <span class="text-white">Sandy</span>

                                        <strong class="d-block text-white">Artist</strong>
                                    </div>
                                </div>

                                <div class="custom-block-info">
                                    <div class="reviews-group mb-3">
                                        <strong>5</strong>

                                        <i class="bi-star-fill"></i>
                                        <i class="bi-star-fill"></i>
                                        <i class="bi-star-fill"></i>
                                        <i class="bi-star-fill"></i>
                                        <i class="bi-star-fill"></i>
                                    </div>

                                    <p class="mb-0">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-4 col-12 my-5 my-lg-0">
                            <div class="custom-block d-flex flex-wrap">
                                <div class="custom-block-image-wrap d-flex flex-column">
                                    <img src="{{ asset('frontend/images/avatar/portrait-young-redhead-bearded-male.jpg')}}" class="img-fluid avatar-image avatar-image-left" alt="">

                                    <div class="text-center mt-3">
                                        <span class="text-white">John</span>

                                        <strong class="d-block text-white">Producer</strong>
                                    </div>
                                </div>

                                <div class="custom-block-info">
                                    <div class="reviews-group mb-3">
                                        <strong>5</strong>

                                        <i class="bi-star-fill"></i>
                                        <i class="bi-star-fill"></i>
                                        <i class="bi-star-fill"></i>
                                        <i class="bi-star-fill"></i>
                                        <i class="bi-star-fill"></i>
                                    </div>

                                    <p class="mb-0">If you need some specific CSS templates, you can Google with keywords such as templatemo one-page, templatemo portfolio, etc.</p>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-4 col-12">
                            <div class="custom-block d-flex flex-wrap">
                                <div class="custom-block-image-wrap d-flex flex-column">
                                    <img src="{{ asset('frontend/images/avatar/pretty-blonde-woman.jpg')}}" class="img-fluid avatar-image" alt="">

                                    <div class="text-center mt-3">
                                        <span class="text-white">Candy</span>

                                        <strong class="d-block text-white">VP, Design</strong>
                                    </div>
                                </div>

                                <div class="custom-block-info">
                                    <div class="reviews-group mb-3">
                                        <strong>5</strong>

                                        <i class="bi-star-fill"></i>
                                        <i class="bi-star-fill"></i>
                                        <i class="bi-star-fill"></i>
                                        <i class="bi-star-fill"></i>
                                        <i class="bi-star-fill"></i>
                                    </div>

                                    <p class="mb-0">Please tell your friends about our website that we provide 100% free CSS templates for everyone. Thank you for using our templates.</p>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </section>


            <section class="contact-section section-padding" id="section_5">
                <div class="container">
                    <div class="row">

                        <div class="col-lg-5 col-12 mx-auto">
                            <form class="custom-form ebook-download-form bg-white shadow" action="#" method="post" role="form">
                                <div class="text-center mb-5">
                                    <h2 class="mb-1">Contact Us</h2>
                                </div>

                                <div class="ebook-download-form-body">
                                    <div class="input-group mb-4">
                                        <input type="text" name="ebook-form-name" id="ebook-form-name" class="form-control" aria-label="ebook-form-name" aria-describedby="basic-addon1" placeholder="Your Name" required>

                                        <span class="input-group-text" id="basic-addon1">
                                            <i class="custom-form-icon bi-person"></i>
                                        </span>
                                    </div>

                                    <div class="input-group mb-4">
                                        <input type="email" name="ebook-email" id="ebook-email" pattern="[^ @]*@[^ @]*" class="form-control" placeholder="your@company.com" aria-label="ebook-form-email" aria-describedby="basic-addon2" required="">

                                        <span class="input-group-text" id="basic-addon2">
                                            <i class="custom-form-icon bi-envelope"></i>
                                        </span>
                                    </div>

                                    <div class="col-lg-8 col-md-10 col-8 mx-auto">
                                        <button type="submit" class="form-control">Send</button>
                                    </div>
                                </div>
                            </form>
                        </div>

                        <div class="col-lg-6 col-12">
                            <h6 class="mt-5">Say hi and talk to us</h6>

                            <h2 class="mb-4">Contact</h2>

                            <!-- <p class="mb-3">
                                <i class="bi-geo-alt me-2"></i>
                                London, United Kingdom
                            </p>

                            <p class="mb-2">
                                <a href="tel: 010-020-0340" class="contact-link">
                                    010-020-0340
                                </a>
                            </p> -->

                            <p>
                                <a href="mailto:{{$email_text->description}}" class="contact-link">
                                    {{$email_text->description}}
                                </a>
                            </p>

                            <h6 class="site-footer-title mt-5 mb-3">Social</h6>

                            <ul class="social-icon mb-4">
                                <li class="social-icon-item">
                                    <a href="{{$insta_link->description}}" class="social-icon-link bi-instagram"></a>
                                </li>

                                <li class="social-icon-item">
                                    <a href="{{$twitter_link->description}}" class="social-icon-link bi-twitter"></a>
                                </li>
                                
                                <li class="social-icon-item">
                                    <a href="{{$facebook_link->description}}" class="social-icon-link bi-facebook"></a>
                                </li>

                                {{-- <li class="social-icon-item">
                                    <a href="{{$email_text->description}}" class="social-icon-link bi-whatsapp"></a>
                                </li> --}}
                            </ul>

                            <p class="copyright-text">Copyright © Agency-Consulting Co. 2023
                            <br><br><a rel="nofollow" href="" target="_blank">developed by NHT</a></p>
                        </div>

                    </div>
                </div>
            </section>
        </main>

        <!-- JAVASCRIPT FILES -->
        <script src="{{ asset('frontend/js/jquery.min.js')}}"></script>
        <script src="{{ asset('frontend/js/bootstrap.bundle.min.js')}}"></script>
        <script src="{{ asset('frontend/js/jquery.sticky.js')}}"></script>
        <script src="{{ asset('frontend/js/click-scroll.js')}}"></script>
        <script src="{{ asset('frontend/js/custom.js')}}"></script>

    </body>
</html>